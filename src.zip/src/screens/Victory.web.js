export const VictoryPie = require('victory').VictoryPie;
export const VictoryTooltip = require('victory').VictoryTooltip;
export const VictoryChart = require('victory').VictoryChart;
export const VictoryBar = require('victory').VictoryBar;
export const VictoryLabel = require('victory').VictoryLabel;
export const VictoryScatter = require('victory').VictoryScatter;
export const VictoryTheme = require('victory').VictoryTheme;